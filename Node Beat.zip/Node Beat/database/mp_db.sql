-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2022 at 09:35 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `music_list`
--

CREATE TABLE `music_list` (
  `id` int(30) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `audio_path` text DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `user_id` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `music_list`
--

INSERT INTO `music_list` (`id`, `title`, `description`, `audio_path`, `image_path`, `user_id`, `date_created`, `date_updated`) VALUES
(1, 'Your april fools', 'Your april fools sample description', './audio/0_7!!_-_Orange_[Shigatsu_wa_Kimi_no_Uso_ED_2]_Lyrics[1].mp3?v=1654241313', './images/0_FB_IMG_16527068449043197[1].jpg?v=1654241313', '1', '2022-06-03 15:28:33', '2022-06-03 15:28:33'),
(2, 'Josie Tiger and the fish ', 'Josie Tiger and the fish song description', './audio/蒼のワルツ_-_Eve_MV[1].mp3?v=1654241402', './images/IMG_20220522_095115[1].jpg?v=1654241402', '1', '2022-06-03 15:30:02', '2022-06-03 15:30:02'),
(3, 'Dress up', 'Sample Descrip', './audio/1_0_Sono_Bisque_Doll_wa_Koi_wo_Suru_Ending_Full『Koi_no_Yukue』by_Akari_Akase[1].mp3?v=1654241570', './images/FB_IMG_16533200554227327[2].jpg?v=1654241570', '1', '2022-06-03 15:32:50', '2022-06-03 15:32:50'),
(4, 'Imong name', 'Description sample', './audio/スパークル_[original_ver.]_-Your_name._Music_Video_edition-_予告編_from_new_album「人間開花」初回盤DVD[1].mp3?v=1654241654', './images/0_FB_IMG_16535333471065067[1].jpg?v=1654241654', '1', '2022-06-03 15:34:14', '2022-06-03 15:34:41');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_music_owner`
--

CREATE TABLE `tbl_music_owner` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_music_owner`
--

INSERT INTO `tbl_music_owner` (`id`, `username`, `name`, `email`, `password`) VALUES
(1, 'kurumi', 'Tokisaki Kurumi I', 'vanitascarte88@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `music_list`
--
ALTER TABLE `music_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_music_owner`
--
ALTER TABLE `tbl_music_owner`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `music_list`
--
ALTER TABLE `music_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_music_owner`
--
ALTER TABLE `tbl_music_owner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
