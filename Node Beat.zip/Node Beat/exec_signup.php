





<?php 
    require_once 'db_connect.php'; 

    $iferrors = True;

    $username = $_POST['username'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];




if($password != $cpassword){
    $iferrors = False;
    echo '<script>alert("Password and Confirm password did not match! ")</script>';
    echo '<script>window.location="signup.php"</script>';
}



    $sql_sel ="SELECT * FROM tbl_music_owner";
    $result_stud =$conn-> query($sql_sel);
    if($result_stud-> num_rows > 0){
        while ($row_s = $result_stud -> fetch_assoc()) {
            if($row_s['username'] == $susername ){
                echo '<script>alert("Username already used! ")</script>';
                echo '<script>window.location="signup.php"</script>';
                $iferrors = False;

                }
            }
        }






if($iferrors){

    $insert = $conn->query("INSERT into tbl_music_owner (
        username,name,email,password) VALUES ('$username','$name','$email','$password')"); 
                         
    if($insert){ 
        echo '<script>alert("Signup Success proceed login")</script>';
        echo '<script>window.location="login.php"</script>';


    }else{ 
  
        echo '<script>alert("Signup failed, check configuration")</script>';
        echo '<script>window.location="signup.php"</script>';
        
    }
}
    





  
    
?>