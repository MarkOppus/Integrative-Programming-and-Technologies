<?php 
session_start();


    $usr = $_POST['username'];
    $pas = $_POST['password'];

    require_once 'db_connect.php'; 
    
    $sql_data_one ="SELECT * FROM tbl_music_owner";
    $result_data_one =$conn-> query($sql_data_one);

    $bolleahn = "no";
    $user_id = "";
    $user_name = "";



    if($result_data_one-> num_rows > 0){
        while ($row_dash = $result_data_one -> fetch_assoc()) {
            if($row_dash["username"] == $usr && $row_dash["password"] == $pas){
                $bolleahn = "yes";
                $user_id = $row_dash["id"];
                $user_name = $row_dash["name"];

            }
        }

    }

    if($bolleahn =="yes"){
        echo '<script>window.location="player.php"</script>';
        $_SESSION["user_id_session"] = $user_id;
        $_SESSION["user_name_session"] = $user_name;

    }
    else{
            echo '<script>alert("Invalid Username or Password")</script>';
            echo '<script>window.location="login.php"</script>';
        }

?>