
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="css/style_cred.css">

    <title>Admin Login | NODE BEAT</title>


<style>

a{
    font-size: 12px;
    text-decoration: none;
    color: black;
    font-weight: 600;
    margin-left: 20px;
}

</style>





<body>

<div class="header">
    <p class="logo">NODE BEAT</p>
</div>
    

<div class="filter_frame" style="height: 300px;">
    <h3>Admin Login</h3>
    <form action="functions.php" method="post">
        <input type="text" name="username" required="" placeholder="Username">
        <p class="labels">Admin username</p>


        <input type="password" name="password" required="" placeholder="Password">
        <p class="labels">Admin password</p>

        <br>
        <div style="text-align:center;">
            <input type="submit" name="verify" class="spec_button"  value="VERIFY">
        </div>
        

    </form>
</div>

</body>
</html>

<body>



