<?php 

require_once('db_connect.php');

 ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Simple Music Player App</title>
    <link rel="stylesheet" href="./font-awesome/css/all.min.css">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/styles.css">
    <script src="./font-awesome/js/all.min.js"></script>
    <script src="./js/jquery-3.6.0.min.js"></script>
    <script src="./js/popper.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/script.js"></script>
    <link rel="stylesheet" href="css/style_cred.css">

    <style>
    .spec_button{
        padding: 7px 20px;
        border-style: solid;
    }
    </style>

</head>

<body >

<div class="header">
    <p class="logo">NODE BEAT</p>


    <p style="float: right; margin-top:-20px; margin-right: 10px;">ADMINISTRATOR</p>
</div>
    


    <script>
        start_loader();
    </script>



<div style="margin: auto; width: 60%; margin-top:30px;">



<div style="text-align:right; margin-bottom: 20px;">
    <button onclick="display_music_f()"  id="music_button" class="spec_button"  style="background-color:  white; color: #212529;">Music List</button>

    <button onclick="display_music_u()"  id="user_button"  class="spec_button">User List</button>
    
</div>

<!-- ========================================= -->

<div id="music_list">
<h4>Music List</h4>


    <div style="overflow: auto; height: 60vh; ">


        <?php 
            $music = $conn->query('SELECT * FROM `music_list` order by title asc');
            while($row = $music->fetch_assoc()):
        ?>
                                <li class=" list-group-item list-group-item-action item" data-id="<?= $row['id'] ?>">
                                    <div class="d-flex w-100 align-items-center">
                                        <div class="col-auto pe-2">
                                            <img src="<?= is_file(explode("?",$row['image_path'])[0]) ? $row['image_path'] : "./images/music-logo.jpg" ?>" alt="" class="img-thumbnail bg-gradient bg-dark mini-display-img">
                                        </div>
                                        <div class="col-auto flex-grow-1 flex-shrink-1">
                                            <p class="m-0 text-truncate" title="<?= $row['title'] ?>"><?= $row['title'] ?></p>
                                        </div>
                                        <div class="col-auto px-2">
                                            <button class="btn btn-outline-primary btn-sm rounded-circle edit" data-id="<?= $row['id'] ?>"><i class="fa fa-edit"></i></button>
                                            <form method="post" action="functions.php" style="display: inline;">
                                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                <input type="hidden" name="type" value="music">
                                                <button name="delet_song" class="btn btn-outline-danger btn-sm rounded-circle delete" data-id="<?= $row['id'] ?>"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </li>
        <?php endwhile; ?>
    </div>

</div>






<!-- ======================================= -->


<div id="user_list" style="Display:none;">
    <h4>User List</h4>


    <div style="overflow: auto; height: 60vh; ">

        <?php 
            $music = $conn->query('SELECT * FROM `tbl_music_owner` order by id asc');
            while($row = $music->fetch_assoc()):
        ?>
                                <li class=" list-group-item list-group-item-action item" data-id="<?= $row['id'] ?>">
                                    <div class="d-flex w-100 align-items-center">
                                        <div class="col-auto flex-grow-1 flex-shrink-1">
                                            <p class="m-0 text-truncate" title="<?= $row['username'] ?>">Name: <?= $row['name'] ?></p>
                                            <p class="m-0 text-truncate" title="<?= $row['username'] ?>">Username: <?= $row['username'] ?></p>
                                            <p class="m-0 text-truncate" title="<?= $row['username'] ?>">Email: <?= $row['email'] ?></p>
                                        </div>
                                        <div class="col-auto px-2">
                                            <form method="post" action="functions.php" style="display: inline;">
                                                <input type="hidden" name="idd" value="<?= $row['id'] ?>">
                                                <input type="hidden" name="type" value="user">
                                                <button name="delet_user" class="btn btn-outline-danger btn-sm rounded-circle delete" data-id="<?= $row['id'] ?>"><i class="fa fa-trash"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </li>
        <?php endwhile; ?>
    </div>


</div>




<!-- =========================== -->




</div>
                          





















        <div class="modal text-dark" id="update_music_modal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered modal-md">
                <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fa fa-music"></i> Update Music Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <form action="" id="update-music-form">
                            <input type="hidden" name="id" >
                            <div class="form-group mb-3">
                                <label for="title2" class="control-label">Title</label>
                                <input type="text" name="title" id="title2" class="form-control form-control-sm rounded-0" required placeholder="XYZ Music">
                            </div>
                            <div class="form-group mb-3">
                                <label for="description2" class="control-label">Description</label>
                                <textarea rows="3" name="description" id="description2" class="form-control form-control-sm rounded-0" required placeholder="Write the description here"></textarea>
                            </div>
                            <div class="form-group mb-3">
                                <label for="audio2" class="control-label">Audio File</label>
                                <input type="file" name="audio" id="audio2" class="form-control form-control-sm rounded-0" accept="audio/*" onchange="displayFileText(this)">
                                <small><i><span class="text-muted">Current:</span> <span id="audio-current"></span></i></small>
                            </div>
                            <div class="form-group mb-3">
                                <label for="img2" class="control-label">Display Image</label>
                                <input type="file" name="img" id="img2" class="form-control form-control-sm rounded-0" accept="image/*" onchange="displayImg(this,'dImage2')">
                            </div>
                            <div class="form-group mb-3 text-center">
                                <div class="col-md-6">
                                <img src="./images/music-logo.jpg" alt="Image" class="img-fluid img-thumbnail bg-gradient bg-dark" id="dImage2">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm rounded-0" form="update-music-form">Save</button>
                    <button type="button" class="btn btn-secondary btn-sm rounded-0" data-bs-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>













<script>
    var btn_music= document.getElementById("music_button");
    var btn_user= document.getElementById("user_button"); 

    var user_list= document.getElementById("user_list"); 
    var music_list= document.getElementById("music_list"); 



function display_music_f() {
    music_list.style.display = "block";
    user_list.style.display = "none"

    btn_music.style.backgroundColor = "white";
    btn_music.style.color = "black";


    btn_user.style.backgroundColor = "#212529";
    btn_user.style.color = "white";

}

function display_music_u() {
    music_list.style.display = "none";
    user_list.style.display = "block"


    btn_music.style.backgroundColor = "#212529";
    btn_music.style.color = "white";


    btn_user.style.backgroundColor = "white"
    btn_user.style.color = "black";
}


</script>


</body>



<?php if(isset($conn) && $conn) @$conn->close(); ?>
</html>