

<?php 
session_start();

    require_once 'db_connect.php'; 
    $iferrors = True;
    $username = $_POST['username'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id = $_SESSION["user_id_session"];



    $insert = $conn->query("UPDATE tbl_music_owner set username = '$username',name = '$name',email = '$email',password = '$password' where id ='$id'"); 
        if($insert){ 
            echo '<script>alert("Updated!")</script>';
            echo '<script>window.location="profile.php"</script>';

        }else{ 
            echo '<script>alert("Not Updated!")</script>';
            echo '<script>window.location="profile.php"</script>';
            
            
        } 







  
    
?>